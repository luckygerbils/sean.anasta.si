#! /usr/bin/python
# -*- coding: utf-8 -*-

#     Copyright 2007-2008 Olivier Schwander <olivier.schwander@ens-lyon.org>
#     Modified Version 2009 Sean Anastasi <sean.anastasi@gmail.com>
#       - Translated messages and comments to English
#       - Additional comments added.
#       - Added album art to notifications.
#       - Notification on playback pause and resume.

#     This program is free software; you can redistribute it and/or modify
#     it under the terms of the GNU General Public License as published by
#     the Free Software Foundation; either version 2 of the License, or
#     (at your option) any later version.

#     This program is distributed in the hope that it will be useful,
#     but WITHOUT ANY WARRANTY; without even the implied warranty of
#     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#     GNU General Public License for more details.

#     You should have received a copy of the GNU General Public License
#     along with this program; if not, write to the Free Software
#     Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

# Requirements:
# You will need pygtk, python-notify, python-mpdclient, python-gtk2 and eyed3

# Usage:
# Simply launch ./mpn.py or ./mpn.py -h for usage help

"""Simple libnotify notifier for mpd"""

import os, sys, cgi
from optparse import OptionParser
import time
import urllib2, urllib
import re
import gettext

import gobject
import gtk
import mpd
import pynotify
import eyeD3

def convert_time(raw):
    """Format a number of seconds to the hh:mm:ss format
    @param raw: A number of seconds.
    @type raw : int

    @return: The hh:mm:ss format of the input.
    @rtype : str
    """
    hour, minutes, sec = ['%02d' % c for c in (raw/3600,
                                               (raw%3600)/60, raw%60)]
    if hour == '00':
        if minutes.startswith('0'):
            minutes = minutes[1:]
        return minutes + ':' + sec
    else:
        if hour.startswith('0'):
            hour = hour[1:]
        return hour + ':' + minutes + ':' + sec

def escape(string):
    """Basic html escaping.  We don't want entity escaping."""
    return string.replace('<', '&lt;').replace('>', '&gt;')


class Notifier:
    "Main class for mpn"
    debug = False
    refresh_time = 500 # in ms
    notify_timeout = 0 # in ms

    # Directory of user's music files
    music_directory = "/home/luckygerbils/Music" 

    # Api key for Amazon Web Services (album art lookup)
    aws_access_key  = "AKIAIGWI7R3UDVR32MIQ"

    host = ""
    mpd = None
    status = None
    current = None
    iterate_handler = None
    paused = None
    notif = None

    def get_host(self):
        """Get hostname from MPD_HOST env variable"""
        host = os.environ.get('MPD_HOST', 'localhost')
        if '@' in host:
            return host.split('@', 1)
        return host

    def get_time(self):
        """Get current time and total length of the current song"""
        time = self.status["time"]
        now, length = [int(c) for c in time.split(':')]
        now_time = convert_time(now)
        length_time = convert_time(length)

        if self.debug:
            print "Position : " + now_time + " / " + length_time
        return (now_time, length_time)

    def get_title(self):
        """Get the current song title"""
        try:
            title = self.current["title"]
        except KeyError:
            title = "???"
            print "<" + _("No title found") + ">"
        if self.debug:
            print _("Title") + " : " + title
        return title

    def get_album(self):
        """Get the current song album"""
        try:
            album = self.current["album"]
        except KeyError:
            album = "???"
            print "<" + _("No album found") + ">"
        if self.debug:
            print _("Album") + " : " + album
        return album

    def get_artist(self):
        """Get the current song artist"""
        try:
            artist = self.current["artist"]
        except KeyError:
            artist = "???"
            print "<"+_("No artist found")+">"
        if self.debug:
            print _("Artist") + " : " + artist
        return artist

    def get_image(self):
        """Get the current song album art."""
        tag = eyeD3.Tag()
        try:
            filename = self.current["file"]
        except KeyError:
            filename = "???"
            print "<" + _("No album art found") + ">"
            return None
        
        tag.link(self.music_directory +"/" + filename)
        print tag.getTitle()
        images = tag.getImages()
        if len(images) == 0:
            if self.debug:
                print _("Album art not found, attempting to download.")

            url = ("http://ecs.amazonaws.com/onca/xml" \
                + "?Service=AWSECommerceService" \
                + "&AWSAccessKeyId=" + self.aws_access_key \
                + "&Operation=ItemSearch" \
                + "&Keywords=" + urllib.quote(tag.getArtist()) + " " + urllib.quote(tag.getAlbum()) \
                + "&SearchIndex=Music" \
                + "&ResponseGroup=ItemAttributes,Images").replace(" ", "+")
            try:
                results = urllib2.urlopen(url).read()
                image = re.search('<MediumImage><URL>(.*?)</URL>', results).group(1)
                image = urllib2.urlopen(image).read()
                with open('/tmp/album_art.jpg', 'w') as f:
                    f.write(image)
                tag.addImage(eyeD3.ImageFrame.OTHER, '/tmp/album_art.jpg')
                tag.update()

                if self.debug:
                    print _("Album art downloaded and saved.")
                
            except Exception as e:
                print "<" + _("Unable to download album art") + ">"
                print e
                return None
        else:
            if self.debug:
                print _("Using valid album art from ID3 tags.")
            image = images[0]
            image.writeFile('/tmp/', 'album_art.jpg')

        try:
            pixbuf = gtk.gdk.pixbuf_new_from_file('/tmp/album_art.jpg')
        except:
            pixbuf = None

        return pixbuf

    def notify(self):
        """Display the notification"""
        just_resumed = False
        just_paused  = False
        just_changed = False

        self.status = self.mpd.status()

        # only if there is a song currently playing
        if not self.status["state"] in ['play', 'pause']:
            if self.debug:
                print _("No song currently playing") + " " + self.host
            return True

        # The very first time MPN is started, do nothing.
        if self.paused == None:
            self.paused  = (self.status["state"] == 'pause')
            self.current = self.mpd.currentsong()
            return True

        # Detect a change from playing to paused.
        if self.status["state"] == 'pause' and not self.paused:
            self.paused  = True
            just_paused  = True

        # Detect a change from paused to playing.
        if self.status["state"] == 'play' and self.paused:
            self.paused  = False
            just_resumed = True

        # Detect a change in song.
        new_current = self.mpd.currentsong()
        if self.current != new_current:
            just_changed = True
            self.current = new_current
            
        if not (just_resumed or just_paused or just_changed):
            return True

        # Get values and make the strings html safe
        album  = escape(self.get_album())
        title  = escape(self.get_title())
        artist = escape(self.get_artist())
        current, length = self.get_time()
        image  = self.get_image()
  
        # Compose the body of the notification.
        body = _("by") + " <b>" + artist + "</b>\n" + \
               "<i>" + album + "</i>\n" + \
               _("Length") + " : " + length

        # Set parameters and display the notification.
        if not self.notif:
          self.notif = pynotify.Notification(title, body)
        else:
          self.notif.update(title, body)

        if image:
            self.notif.set_icon_from_pixbuf(image)
            self.notif.set_timeout(self.notify_timeout)
        if not self.notif.show():
            print "<" + _("Unable to show the notification") + ">"
            return False

        return True

    def run(self):
        """Launch the iteration"""
        self.iterate_handler = gobject.timeout_add(self.refresh_time,
                                                   self.notify)

    def __init__(self, debug=False, notify_timeout=3):
        """Initialisation of mpd client and pynotify"""
        self.debug = debug
        # param notify_timeout is in seconds
        self.notify_timeout = 1000 * notify_timeout
        self.host = self.get_host()

        try:
            self.mpd = mpd.MPDClient();
            self.mpd.connect(self.host, 6600);
        except mpd.socket.error:
            print _("Unable to connect to the server") + " " + self.host
            sys.exit(1)

        pynotify.init('mpn')

if __name__ == "__main__":
    # initialize localization
    gettext.install('mpn')

    # initializate the argument parser
    PARSER = OptionParser()

    # help/debug mode
    PARSER.set_defaults(debug = False)
    PARSER.add_option(      "--debug",               action="store_true",  dest="debug",   help="Turn on debugging information")
    PARSER.add_option(      "--log", type="string",  action="store",       dest="log",     help="Log errors or debugging information to the given file.")
    PARSER.set_defaults(log = None)
    # Will mpn fork?
    PARSER.add_option("-d", "--daemon",              action="store_true",  dest="fork",    help="Fork into the background")
    PARSER.add_option("-n", "--nodaemon",            action="store_false", dest="fork",    help="Do not daemonize into background (default)")
    PARSER.set_defaults(fork = False)
    # Amount of time to show the notification for.
    PARSER.add_option("-t", "--timeout", type="int", action="store",       dest="timeout", help="Notification timeout in secs")
    PARSER.set_defaults(timeout = 3)
    # Mode to send only one notification.
    PARSER.add_option("-o", "--once",                action="store_false", dest="repeat",  help="Notify once and exit")
    PARSER.set_defaults(repeat = True)

    # parse the commandline
    (OPTIONS, ARGS) = PARSER.parse_args()

    # initializate the notifier
    MPN = Notifier(debug=OPTIONS.debug, notify_timeout=OPTIONS.timeout)

    # fork if necessary
    if OPTIONS.fork:
        if os.fork() != 0:
            sys.exit(0)

    if OPTIONS.log:
        sys.stdout = open(OPTIONS.log, 'a', 0)
        print "-"*5 + "MPN Started: " + time.strftime("%H:%M:%S %m/%d/%y") + "-"*5

    # run the notifier
    if OPTIONS.repeat:
        MPN.run()
        gtk.main()
    else:
        MPN.notify()

