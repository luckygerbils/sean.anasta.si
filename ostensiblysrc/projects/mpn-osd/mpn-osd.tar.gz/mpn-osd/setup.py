#! /usr/bin/env python

import os, glob, shutil, sys
from distutils.core import setup, Command

APPLICATION_NAME    = 'MPN'
APPLICATION_VERSION = '1.2'
EXECUTABLE_NAME     = 'mpn'
PO_LANGUAGE_DIR     = 'po'
MO_LANGUAGE_DIR     = 'mo'
BIN_DIR             = 'bin'

language_files = []

if sys.argv[1] == 'install':
    #
    # Create .mo language files.
    #
    if not os.path.exists(MO_LANGUAGE_DIR + '/'):
        os.mkdir(MO_LANGUAGE_DIR)

    for langfile in os.listdir(PO_LANGUAGE_DIR):
        if not (langfile == '.' or langfile == '..' or langfile == 'messages.pot'):
            lang = langfile[:-3]

            mofile = MO_LANGUAGE_DIR + '/' + lang + '/' + EXECUTABLE_NAME + '.mo'
            pofile = PO_LANGUAGE_DIR + '/' + lang + '.po'
            language_files.append(("share/locale/" + lang + "/LC_MESSAGES", [mofile]))

            if not os.path.exists(os.path.dirname(mofile)):
                os.mkdir(os.path.dirname(mofile))
            print "Generating", mofile
            os.system("msgfmt {0} -o {1}".format(pofile, mofile))

    #
    # Copy executable to bin dir.
    #
    if not os.path.exists(BIN_DIR + '/'):
        os.mkdir(BIN_DIR)
    shutil.copyfile(EXECUTABLE_NAME + ".py", BIN_DIR + "/" + EXECUTABLE_NAME)

#
# Do setup.
#
setup(
    name         = APPLICATION_NAME,
    version      = APPLICATION_VERSION,
    description  = "A simple libnotify application for Music Player Daemon (MPD).",
    author       = "Olivier Schwander, Sean Anastasi",
    author_email = "olivier.schwander@ens-lyon.org, sean.anastasi@gmail.com",
    scripts      = [BIN_DIR + '/' + EXECUTABLE_NAME],
    requires     = ['eyeD3', 'mpd', 'pynotify', 'gtk'],
    data_files = language_files
)

